
package Hotel;


public enum Status {
    AVAILABLE,
    BOOKED;
}
