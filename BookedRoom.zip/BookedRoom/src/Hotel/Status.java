
package Hotel;


public enum Status {
    
}
