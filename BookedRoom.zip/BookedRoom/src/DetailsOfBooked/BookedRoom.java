
package DetailsOfBooked;

public class BookedRoom {
    
}
