
package Room;

public abstract class TypeOfRoom {
    
}
